
// 被强奸后随机被随机抢劫一些物品
function lostItemsAfterRape() {

}

// 塑料袋随着使用时间的增加，而增加破损概率。
// 破损时，装在里面的物品会掉落在地上。
function plasticBagBroken() {


}

// 随机的抢劫事件处理
function randomRobbery() {

}


// 拾取物品事件处理
function pickUpHandle() {


}


// 收获物品事件处理
function harvestHandle() {

    
}
