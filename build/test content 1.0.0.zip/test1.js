console.log('test1.js')

simpleFrameworks.addto('iModInit', 'testInit')