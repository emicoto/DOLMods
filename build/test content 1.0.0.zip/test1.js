console.log('test1.js')
