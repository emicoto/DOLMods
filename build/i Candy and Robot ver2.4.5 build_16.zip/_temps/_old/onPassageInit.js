//passage刚初始化的时候。啥都还没run，比ready还早。
//div元素还没准备好！没法进行文本处理！！
//但可以直接对innerHtml进行实时修改

$(document).on(':passageinit', (data)=>{
	let { passage } = data

		
})