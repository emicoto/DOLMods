console.log('test1.js');

simpleFrameworks.addto('iModReady', 'initMoney');
simpleFrameworks.addto('iModHeader', 'checkMoneyFunc');
simpleFrameworks.addto('iModFooter', 'checkMoneyFunc');
