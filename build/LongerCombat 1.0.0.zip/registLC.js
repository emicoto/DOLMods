
simpleFrameworks.addto('iModOptions', 'longerCombatConfig')