
simpleFrameworks.addto('iModOptions', 'longerCombatConfig');
