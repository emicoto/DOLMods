class iMap {
    static location() {
        // 巴士里直接返回巴士
        if (V.passage == 'Bus' || V.passage.includes('Bus')) {
            return 'bus';
        }

        if (V.passage.includes('Stall')) {
            return 'market';
        }

        if (V.location == 'town') {
            // 根据bus返回
            return V.bus;
        }

        if (V.location == 'farm' && V.passage.includes('Livestock')) {
            return 'livestock';
        }

        if (V.location == 'alley') {
            // 根据passage返回地点
            if (V.passage.includes('Commercial')) return 'commercial_alley';
            if (V.passage.includes('Industrial')) return 'industrial_alley';
            if (V.passage.includes('Residential')) return 'residential_alley';
        }

        return V.location;
    }

    constructor(variable, stageId) {
        this.name = variable;
        this.stageId = stageId;
        this.display = {
            EN : '',
            CN : ''
        };
        this.entry = [];
        this.group = 'doltown';
        this.type = 'street';
        this.tags = [];
        this.locations = {};
        this.transport = {
            bike   : false,
            bus    : false,
            portal : false
        };
    }

    /**
     * @description set the display name of this map
     * @param  {...string | object } language
     * @returns {iMap}
     */
    Display(...language) {
        if (language.length == 1 && String(language[0]) == '[object Object]') {
            this.display = language[0];
        }
        else {
            const list = ['EN', 'CN', 'JP'];
            for (let i = 0; i < language.length; i++) {
                const text = language[i];
                this.display[list[i]] = text;
            }
        }
        return this;
    }

    /**
     * @description set the entry passage of this map
     * @param  {...string} passage
     * @returns {iMap}
     */
    Entry(...passage) {
        this.entry = passage;

        // if entry passage just one, set it as default group
        if (this.entry.length == 1) {
            this.group = this.entry[0];
        }
        return this;
    }

    /**
     * @description set the group of this map
     * @param {string} group
     * @returns {iMap}
     */
    Group(group) {
        this.group = group;
        return this;
    }

    /**
     * @description set the type of this map
     * @param {'building' | 'forest' | 'plain' | 'shore' | 'water' | 'underground' | 'special' } type
     * @returns {iMap}
     */

    Type(type) {
        this.type = type;

        // if type is building, set it as indoor location
        if (type == 'building') {
            this.indoor = 1;
        }
        return this;
    }

    /**
     * @description set the functional tags of this location
     * @param  {...'mainstage' | 'maze' | 'business' | 'activity' | 'shelter' | 'mobilestall' | 'waterspot' | 'cave'} tags
     * @returns {iMap}
     */
    Tags(...tags) {
        this.tags = tags;
        return this;
    }

    /**
     * @description set the available locations and the position relation of this map
     * @param {{ [location: string] : number }} locations
     * @returns {iMap}
     */
    Locations(locations) {
        this.locations = locations;
        return this;
    }

    /**
     * @description set the transportation of this map
     * @param  {'bike' | 'bus' | 'portal'} transport
     * @returns {iMap}
     */
    Transport(...transport) {
        transport.forEach(t => {
            this.transport[t] = true;
        });
        return this;
    }

    /**
     * @description set condition of the location, which will be checked when pc in the entry passage
     * @param {function} cond
     * @returns {iMap}
     */
    Cond(cond) {
        this.cond = cond;
        return this;
    }

    /**
     * @description set the business hours of this location
     * @param {number[]} ...hours
     * @returns {iMap}
     */
    BusinessHours(...hours) {
        this.businessHours = hours;
        return this;
    }

    /**
     * @description set the available actions of this location
     * @param  {...object} actions
     * @returns {iMap}
     */
    Actions(...actions) {
        this.actions = actions;
        return this;
    }

    /**
     * @description set the area group of this location
     */
    Area(area) {
        this.area = area;
        return this;
    }


    /**
     * @description set the taninng multiplier of this location
     * @param {number} multiplier
     */
    Tanning(multiplier) {
        this.tanning = multiplier;
        return this;
    }
}

const Tauyuan = {
    Chinatown : new iMap('chinatown', 'Chinatown')
        .Display('Chinatown', '唐人街')
        .Entry('AlmondForest')
        .Group('Tauyuan')
        .Type('town')
        .Tags('mainstage', 'mobilestall')
        .Locations({
            almond     : -5,
            chinatown  : 0,
            snackshop  : 1,
            taipark    : 3,
            kongfucafe : 5,
            teagarden  : 6,
            shingwong  : 7,
            institude  : 8,
            bathcenter : 10,
            moonforest : 15
        })
        .Transport('bike'),
    
    AlmondForest : new iMap('almond', 'AlmondForest')
        .Display('Almond Forest', '杏花林')
        .Entry('Harvest Street', 'Mer Street')
        .Group('Tauyuan')
        .Type('forest')
        .Tags('mainstage', 'maze')
        // 地点连接出现在entry passage的条件。
        .Cond(() => iStage.getFlag('chinatown', 'known') && !between(Time.hour, 8, 12))
        .Locations({
            mer       : -2,
            harvest   : -1,
            almond    : 0,
            chinatown : 5
        }),
    
    SnackShop : new iMap('snackshop', 'SnackShop')
        .Display('Snack Shop', '小吃店')
        .Entry('Chinatown')
        .Type('building')
        .Tags('business')
        .BusinessHours([9, 17])
        .Locations({
            chinatown : -1,
            snackshop : 0
        }),
    
    TaiPark : new iMap('taipark', 'TaiPark')
        .Display('Taichi Park', '太极公园')
        .Entry('Chinatown')
        .Type('park')
        .Tags('activity', 'shelter')
        .Locations({
            chinatown : -1,
            taipark   : 0
        }),
    
    KongfuCafe : new iMap('kongfucafe', 'KongfuCafe')
        .Display('Kongfu Café', '功夫茶餐厅')
        .Entry('Chinatown')
        .Type('building')
        .Tags('business')
        .BusinessHours([10, 21])
        .Locations({
            chinatown  : -1,
            kongfucafe : 0
        }),
    
    TeaGarden : new iMap('teagarden', 'TeaGarden')
        .Display('Tea Garden', '茶园')
        .Entry('Chinatown')
        .Type('building')
        .Tags('business')
        .BusinessHours([10, 14], [17, 22])
        .Locations({
            chinatown : -1,
            teagarden : 0
        }),
    
    ShingWong : new iMap('shingwong', 'ShingWong')
        .Display('Shing Wong Temple', '城隍庙')
        .Entry('Chinatown')
        .Type('building')
        .Tags('activity')
        .Locations({
            chinatown : -1,
            shingwong : 0
        }),
    
    Institutude : new iMap('institude', 'Institude')
        .Display('Robot Science Institude', '机器人研究所')
        .Entry('Chinatown')
        .Type('building')
        .Tags('activity')
        .Locations({
            chinatown : -1,
            institude : 0
        }),
    
    BathCenter : new iMap('bathcenter', 'BathCenter')
        .Display('Lotus Bath Center', '水木莲华')
        .Entry('Chinatown')
        .Type('building')
        .Tags('business')
        .BusinessHours([10, 22])
        .Locations({
            chinatown  : -1,
            bathcenter : 0
        }),
    
    MoonForest : new iMap('moonforest', 'MoonForest')
        .Display('Moon Forest', '月光森林')
        .Entry('AlmondForest', 'Chinatown')
        .Group('Tauyuan')
        .Type('forest')
        .Tags('mainstage', 'maze', 'waterspot')
        .Cond(() => iStage.getFlag('moonforest', 'known'))
        .Locations({
            chinatown  : -15,
            moonforest : 0,
            hotspring  : 10,
            almond     : 20
        }),
    
    Hotspring : new iMap('hotspring', 'HotSpring')
        .Display('Hot Spring', '温泉')
        .Entry('MoonForest')
        .Type('forest')
        .Tags('waterspot')
        .Cond(() => Tvar.moonforest.forward >= 5 && random(100) < 40)
        .Locations({
            moonforest  : -1,
            hotspring   : 0,
            springhouse : 5
        }),
    
    SpringHouse : new iMap('springhouse', 'SpringHouse')
        .Display('Spring House', '温泉屋')
        .Entry('MoonForest', 'Hotspring')
        .Type('building')
        .Tags('safehouse')
        .Cond(() => iMap.location() == 'hotspring' || Tvar.moonforest.forward >= 5 && random(100) < 20)
        .Locations({
            moonforest  : -2,
            hotspring   : -1,
            springhouse : 0
        })
};

const DolTown = {
    'Domus Street' : new iMap('domus', 'Domus Street')
        .Group('DolTown')
        .Area('residential')
        .Type('town')
        .Locations({
            manhole : -5,
            orphanage : -1,
            domus     : 0,
            busstop : 2,
            barb : 5,
            danube : 5,
            
            residential_alley : 5,
        }),

    'Barb Street' : new iMap('barb', 'Barb Street')
        .Group('DolTown')
        .Area('residential')
        .Type('town'),
    
    'Danube Street' : new iMap('danube', 'Danube Street')
        .Group('DolTown')
        .Area('residential')
        .Type('town'),
    
    'Wolf Street' : new iMap('wolf', 'Wolf Street')
        .Group('DolTown')
        .Area('residential')
        .Type('town'),
    
    'High Street' : new iMap('high', 'High Street')
        .Group('DolTown')
        .Area('commercial')
        .Type('town'),
    
    'Connudatus Street' : new iMap('connudatus', 'Connudatus Street')
        .Group('DolTown')
        .Area('commercial')
        .Type('town'),

    'Cliff Street' : new iMap('cliff', 'Cliff Street')
        .Group('DolTown')
        .Area('commercial')
        .Type('town'),

    'Nightingale Street' : new iMap('nightingale', 'Nightingale Street')
        .Group('DolTown')
        .Area('commercial')
        .Type('town'),

    'Starfish Street' : new iMap('starfish', 'Starfish Street')
        .Group('DolTown')
        .Area('commercial')
        .Type('town'),
    
    'Oxford Street' : new iMap('oxford', 'Oxford Street')
        .Group('DolTown')
        .Area('commercial')
        .Type('town'),
    

    'Elk Street' : new iMap('elk', 'Elk Street')
        .Group('DolTown')
        .Area('industrial')
        .Type('town'),
    
    'Mer Street' : new iMap('mer', 'Mer Street')
        .Group('DolTown')
        .Area('industrial')
        .Type('town'),
    
    'Harvest Street' : new iMap('harvest', 'Harvest Street')
        .Group('DolTown')
        .Area('industrial')
        .Type('town'),
}