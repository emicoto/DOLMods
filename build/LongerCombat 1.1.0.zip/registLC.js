
simpleFrameworks.addto('iModOptions', 'longerCombatConfig');
simpleFrameworks.addto('iModFooter', 'longerCombat');
