
$(document).on(':passageinit', ()=>{
    if (typeof V.SFCheats === 'undefined') {
        V.SFCheats = {
            keepHairs : true
        };
    }
});
