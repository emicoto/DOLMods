
simpleFrameworks.addto('ModShopZone', {
    passage : 'Pharmacy',
    widget  : 'SFnewMedicine'
});
