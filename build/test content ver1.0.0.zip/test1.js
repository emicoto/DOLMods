console.log('test1.js');

simpleFrameworks.addto('iModInit', 'BGMInit');
simpleFrameworks.addto('iModFooter', 'playBGM');