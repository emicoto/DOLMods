console.log('test1.js');

simpleFrameworks.addto('iModFooter', 'testCombat');
