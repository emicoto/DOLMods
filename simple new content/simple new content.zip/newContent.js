$(document).on('simpleFrameworks:ready', ()=>{
    console.log('adding new content')
    alert('adding new content')
    simpleFrameworks.addto('iModHeader', 'aSimpleTest')

})

simpleFrameworks.addto('iModHeader', 'aSimpleTest')