const modTestContent = 'test1.js'
console.log(modTestContent)