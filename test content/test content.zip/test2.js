const modTestContent1 = 'test2.js'
console.log(modTestContent1)